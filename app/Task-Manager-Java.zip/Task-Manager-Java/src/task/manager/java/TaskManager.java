import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class TaskManager {
    private static Connection connection;

    public static void main(String[] args) {
        try {
            // Connect to the database
            connectToDatabase();

            // Show the main interface
            SwingUtilities.invokeLater(TaskManager::showMainInterface);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to connect to the database.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void connectToDatabase() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/TaskManagerDB";
        String username = "root"; // Replace with your MySQL username
        String password = "Fatoma2003"; // Replace with your MySQL password
        connection = DriverManager.getConnection(url, username, password);
    }

    private static void showMainInterface() {
        JFrame mainFrame = new JFrame("Welcome to Task Manager");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(400, 300);
        mainFrame.getContentPane().setBackground(new Color(240, 240, 240));

        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));
        panel.setBackground(new Color(240, 240, 240));

        JButton loginButton = createStyledButton("Log In");
        JButton registerButton = createStyledButton("Register");
        JButton guestButton = createStyledButton("Continue as Guest");

        loginButton.addActionListener(e -> showLoginScreen(mainFrame));
        registerButton.addActionListener(e -> showRegistrationScreen(mainFrame));
        guestButton.addActionListener(e -> showTaskManager(mainFrame, null));

        panel.add(loginButton);
        panel.add(registerButton);
        panel.add(guestButton);

        mainFrame.add(panel);
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
    }

    private static JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        return button;
    }

    private static void showLoginScreen(JFrame mainFrame) {
        mainFrame.getContentPane().removeAll();
        mainFrame.setTitle("Log In");

        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));
        panel.setBackground(new Color(240, 240, 240));

        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();

        JButton loginButton = createStyledButton("Log In");
        JButton backButton = createStyledButton("Back");

        panel.add(new JLabel("Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);
        panel.add(loginButton);
        panel.add(backButton);

        loginButton.addActionListener(e -> {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword());

            try {
                if (validateLogin(username, password)) {
                    JOptionPane.showMessageDialog(mainFrame, "Login successful!");
                    showTaskManager(mainFrame, username);
                } else {
                    JOptionPane.showMessageDialog(mainFrame, "Invalid username or password.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(mainFrame, "Error during login.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        backButton.addActionListener(e -> showMainInterface());

        mainFrame.add(panel);
        mainFrame.revalidate();
        mainFrame.repaint();
    }

    private static void showRegistrationScreen(JFrame mainFrame) {
        mainFrame.getContentPane().removeAll();
        mainFrame.setTitle("Register");

        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10));
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));
        panel.setBackground(new Color(240, 240, 240));

        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JPasswordField confirmPasswordField = new JPasswordField();

        JButton registerButton = createStyledButton("Register");
        JButton backButton = createStyledButton("Back");

        panel.add(new JLabel("Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);
        panel.add(new JLabel("Confirm Password:"));
        panel.add(confirmPasswordField);
        panel.add(registerButton);
        panel.add(backButton);

        registerButton.addActionListener(e -> {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword());
            String confirmPassword = new String(confirmPasswordField.getPassword());

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(mainFrame, "Fields cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (!password.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(mainFrame, "Passwords do not match.", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (!isStrongPassword(password)) {
                JOptionPane.showMessageDialog(mainFrame,
                        "Password must be at least 8 characters long, contain uppercase, lowercase, digit, and a special character.",
                        "Weak Password",
                        JOptionPane.ERROR_MESSAGE);
            } else {
                try {
                    if (registerUser(username, password)) {
                        JOptionPane.showMessageDialog(mainFrame, "Registration successful!");
                        showMainInterface();
                    } else {
                        JOptionPane.showMessageDialog(mainFrame, "Username already exists.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(mainFrame, "Error during registration.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        backButton.addActionListener(e -> showMainInterface());

        mainFrame.add(panel);
        mainFrame.revalidate();
        mainFrame.repaint();
    }

    private static void showTaskManager(JFrame mainFrame, String username) {
    mainFrame.getContentPane().removeAll();
    mainFrame.setTitle(username == null ? "Guest Task Manager" : username + "'s Task Manager");

    mainFrame.setSize(800, 600);
    mainFrame.setLocationRelativeTo(null); // Center the window on the screen

    JPanel mainPanel = new JPanel(new BorderLayout());
    JPanel addTaskPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
    addTaskPanel.setBackground(new Color(255, 250, 240));

    JTextField taskField = new JTextField(25);
    JTextField dateField = new JTextField(12);
    dateField.setToolTipText("Enter date in yyyy-MM-dd format");
    JButton addButton = createStyledButton("Add Task");

    addTaskPanel.add(new JLabel("Task:"));
    addTaskPanel.add(taskField);
    addTaskPanel.add(new JLabel("Date (yyyy-MM-dd):"));
    addTaskPanel.add(dateField);
    addTaskPanel.add(addButton);

    JPanel taskListPanel = new JPanel();
    taskListPanel.setLayout(new BoxLayout(taskListPanel, BoxLayout.Y_AXIS));
    taskListPanel.setBackground(new Color(240, 248, 255));
    JScrollPane scrollPane = new JScrollPane(taskListPanel);
    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
    scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

    JButton sortButton = createStyledButton("Sort by Date");
    JButton goBackButton = createStyledButton("Go Back");

    goBackButton.addActionListener(e -> {
        mainFrame.dispose();
        showMainInterface();
    });

    addButton.addActionListener(e -> {
        String taskDescription = taskField.getText().trim();
        String taskDateText = dateField.getText().trim();

        if (taskDescription.isEmpty()) {
            JOptionPane.showMessageDialog(mainFrame, "Task description cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            LocalDate taskDate = taskDateText.isEmpty() ? LocalDate.now() : LocalDate.parse(taskDateText);

            if (username == null) {
                addGuestTask(taskListPanel, taskDescription, taskDate);
            } else {
                saveTaskToDatabase(username, taskDescription, taskDate);
                loadTasks(taskListPanel, username);
            }

            taskField.setText("");
            dateField.setText("");
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(mainFrame, "Invalid date format. Use yyyy-MM-dd.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(mainFrame, "Error adding task to database.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    });

    sortButton.addActionListener(e -> sortTasks(taskListPanel, username));

    if (username != null) {
        loadTasks(taskListPanel, username);
    }

    JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    bottomPanel.setBackground(new Color(255, 250, 240));
    bottomPanel.add(goBackButton);
    bottomPanel.add(sortButton);

    mainPanel.add(addTaskPanel, BorderLayout.NORTH);
    mainPanel.add(scrollPane, BorderLayout.CENTER);
    mainPanel.add(bottomPanel, BorderLayout.SOUTH);

    mainFrame.add(mainPanel);
    mainFrame.revalidate();
    mainFrame.repaint();
}


    private static void addGuestTask(JPanel taskListPanel, String taskDescription, LocalDate taskDate) {
    JPanel taskPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
    taskPanel.setBackground(new Color(245, 245, 245));
    taskPanel.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1));

    // Task description checkbox
    JCheckBox taskCheckbox = new JCheckBox(taskDescription + " (Due: " + taskDate + ")");
    taskCheckbox.setFont(new Font("Arial", Font.PLAIN, 14));
    taskPanel.add(taskCheckbox);

    // Delete button
    JButton deleteButton = createStyledButton("Delete");
    deleteButton.setPreferredSize(new Dimension(100, 30)); // Ensure enough space for the text
    deleteButton.addActionListener(e -> {
        taskListPanel.remove(taskPanel);
        taskListPanel.revalidate();
        taskListPanel.repaint();
    });
    taskPanel.add(deleteButton);

    taskListPanel.add(taskPanel);
    taskListPanel.revalidate();
    taskListPanel.repaint();
}


private static void loadTasks(JPanel taskListPanel, String username) {
    try {
        taskListPanel.removeAll();

        String query = "SELECT t.id, t.description, t.due_date, t.completed FROM tasks t "
                + "JOIN users u ON t.user_id = u.id "
                + "WHERE u.username = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, username);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int taskId = rs.getInt("id");
                    String description = rs.getString("description");
                    LocalDate dueDate = rs.getDate("due_date").toLocalDate();
                    boolean completed = rs.getBoolean("completed");

                    JPanel taskPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
                    taskPanel.setBackground(new Color(245, 245, 245));
                    taskPanel.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1));

                    JCheckBox taskCheckbox = new JCheckBox(description + " (Due: " + dueDate + ")", completed);
                    taskCheckbox.setFont(new Font("Arial", Font.PLAIN, 14));
                    taskCheckbox.addActionListener(evt -> {
                        try {
                            updateTaskCompletionStatus(taskId, taskCheckbox.isSelected());
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                            JOptionPane.showMessageDialog(taskListPanel, "Error updating task completion status.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    });
                    taskPanel.add(taskCheckbox);

                    JButton deleteButton = createStyledButton("Delete");
                    deleteButton.setPreferredSize(new Dimension(100, 30)); // Ensure enough space for the text
                    deleteButton.addActionListener(evt -> {
                        try {
                            deleteTaskFromDatabase(taskId);
                            loadTasks(taskListPanel, username);
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                            JOptionPane.showMessageDialog(taskListPanel, "Error deleting task.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    });
                    taskPanel.add(deleteButton);

                    taskListPanel.add(taskPanel);
                }
            }
        }

        taskListPanel.revalidate();
        taskListPanel.repaint();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}


    private static void sortTasks(JPanel taskListPanel, String username) {
    try {
        taskListPanel.removeAll();

        List<Task> tasks = new ArrayList<>();

        String query = "SELECT t.id, t.description, t.due_date, t.completed FROM tasks t "
                + "JOIN users u ON t.user_id = u.id "
                + "WHERE u.username = ?";

        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, username);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int taskId = rs.getInt("id");
                    String description = rs.getString("description");
                    LocalDate dueDate = rs.getDate("due_date").toLocalDate();
                    boolean completed = rs.getBoolean("completed");

                    tasks.add(new Task(taskId, description, dueDate, completed));
                }
            }
        }

        // Sort tasks by due date
        tasks.sort(Comparator.comparing(Task::getDueDate));

        // Add sorted tasks to the panel
        for (Task task : tasks) {
            JPanel taskPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
            taskPanel.setBackground(new Color(245, 245, 245));
            taskPanel.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1));

            JCheckBox taskCheckbox = new JCheckBox(task.getDescription() + " (Due: " + task.getDueDate() + ")", task.isCompleted());
            taskCheckbox.setFont(new Font("Arial", Font.PLAIN, 14));
            taskCheckbox.addActionListener(evt -> {
                try {
                    updateTaskCompletionStatus(task.getId(), taskCheckbox.isSelected());
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(taskListPanel, "Error updating task completion status.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            });
            taskPanel.add(taskCheckbox);

            JButton deleteButton = createStyledButton("Delete");
            deleteButton.setPreferredSize(new Dimension(100, 30)); // Ensure proper size for the button
            deleteButton.addActionListener(evt -> {
                try {
                    deleteTaskFromDatabase(task.getId());
                    sortTasks(taskListPanel, username); // Reload sorted tasks
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(taskListPanel, "Error deleting task.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            });
            taskPanel.add(deleteButton);

            taskListPanel.add(taskPanel);
        }

        taskListPanel.revalidate();
        taskListPanel.repaint();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}


    private static void updateTaskCompletionStatus(int taskId, boolean completed) throws SQLException {
        String query = "UPDATE tasks SET completed = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setBoolean(1, completed);
            stmt.setInt(2, taskId);
            stmt.executeUpdate();
        }
    }

    private static void saveTaskToDatabase(String username, String description, LocalDate dueDate) throws SQLException {
        String query = "INSERT INTO tasks (user_id, description, due_date, completed) VALUES ((SELECT id FROM users WHERE username = ?), ?, ?, FALSE)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, description);
            stmt.setDate(3, Date.valueOf(dueDate));
            stmt.executeUpdate();
        }
    }

    private static void deleteTaskFromDatabase(int taskId) throws SQLException {
        String query = "DELETE FROM tasks WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, taskId);
            stmt.executeUpdate();
        }
    }

    private static boolean validateLogin(String username, String password) throws SQLException {
        String query = "SELECT * FROM users WHERE username = ? AND password = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    private static boolean isStrongPassword(String password) {
        if (password.length() < 8) {
            return false;
        }
        boolean hasUppercase = false;
        boolean hasLowercase = false;
        boolean hasDigit = false;
        boolean hasSpecialChar = false;
        for (char ch : password.toCharArray()) {
            if (Character.isUpperCase(ch)) hasUppercase = true;
            else if (Character.isLowerCase(ch)) hasLowercase = true;
            else if (Character.isDigit(ch)) hasDigit = true;
            else if (!Character.isLetterOrDigit(ch)) hasSpecialChar = true;
        }
        return hasUppercase && hasLowercase && hasDigit && hasSpecialChar;
    }

    private static boolean registerUser(String username, String password) throws SQLException {
        String query = "INSERT INTO users (username, password) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.executeUpdate();
            return true;
        } catch (SQLIntegrityConstraintViolationException e) {
            return false; // Username already exists
        }
    }
}

class Task {
    private int id;
    private String description;
    private LocalDate dueDate;
    private boolean completed;

    public Task(int id, String description, LocalDate dueDate, boolean completed) {
        this.id = id;
        this.description = description;
        this.dueDate = dueDate;
        this.completed = completed;
    }

    public int getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public boolean isCompleted() {
        return completed;
    }
}
